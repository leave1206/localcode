// ==Xiaohongshu Comment Collector==

// 1. 隐藏 webdriver 痕迹
try {
  Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
} catch(e) {}

const MAX_LOOP = 30; // 降低最大循环次数，减少滑动
const MAX_COMMENTS = 100; // 达到100条评论即终止

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function randomBetween(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getNoteIdFromUrl() {
  const m = window.location.pathname.match(/\/explore\/(\w+)/);
  return m ? m[1] : '';
}

function getAllCommentsDetail() {
  const commentNodes = document.querySelectorAll('.comments-container .comment-item, .comments-container [data-testid="comment-item"]');
  return Array.from(commentNodes).map(node => {
    // 评论内容
    let content = '';
    let user = '';
    let time = '';
    // 内容
    const contentNode = node.querySelector('.content, [data-testid="comment-content"], .note-text');
    if (contentNode) content = contentNode.innerText.trim();
    // 用户昵称
    const userNode = node.querySelector('.author .name');
    if (userNode) user = userNode.innerText.trim();
    // 时间
    const timeNode = node.querySelector('.info .date span');
    if (timeNode) time = timeNode.innerText.trim();
    return { content, user, time };
  }).filter(c => c.content);
}

function getTodayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `xhs_comments_${y}${m}${day}.json`;
}

function saveNoteCommentsToLocal(noteId, noteUrl, comments) {
  const key = getTodayKey();
  chrome.storage.local.get({[key]: {}}, function(data) {
    let allData = data[key] || {};
    // 查找当前noteId是否已存在编号
    let foundNum = null;
    for (const num in allData) {
      if (allData[num] && allData[num].noteId === noteId) {
        foundNum = num;
        break;
      }
    }
    let useNum = foundNum;
    if (!useNum) {
      const nums = Object.keys(allData).map(n => parseInt(n)).filter(n => !isNaN(n));
      useNum = nums.length > 0 ? (Math.max(...nums) + 1).toString() : '1';
    }
    allData[useNum] = { noteId, noteUrl, comments };
    chrome.storage.local.set({[key]: allData}, function() {
      console.log('已保存评论到chrome.storage.local', key, allData);
    });
  });
}

async function moveMouseToElement(el) {
  if (!el) return;
  const rect = el.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  el.dispatchEvent(new MouseEvent('mousemove', {clientX: x, clientY: y, bubbles: true}));
  await sleep(randomBetween(200, 800));
}

// 2. 偶尔模拟鼠标点击评论区
async function maybeClickRandom() {
  if (Math.random() < 0.12) {
    const container = document.querySelector('.comments-container');
    if (container) {
      const rect = container.getBoundingClientRect();
      const x = rect.left + Math.random() * rect.width;
      const y = rect.top + Math.random() * rect.height;
      container.dispatchEvent(new MouseEvent('click', {clientX: x, clientY: y, bubbles: true}));
      await sleep(randomBetween(200, 800));
    }
  }
}

async function forceLoadAllComments() {
  let lastCount = 0;
  let loop = 0;
  let noNewCount = 0;
  const MAX_NO_NEW = 2;
  try {
    while (loop < MAX_LOOP) {
      // 1. window整体向下滚动，距离和等待时间随机
      window.scrollTo(0, document.body.scrollHeight - randomBetween(0, 200));
      await sleep(randomBetween(1200, 3500));

      // 2. 评论区容器滑动，距离和等待时间随机
      const container = document.querySelector('.comments-container');
      if (container) {
        if (Math.random() < 0.2) {
          container.scrollTop -= randomBetween(50, 200);
          await sleep(randomBetween(800, 2000));
        }
        container.scrollTop += randomBetween(100, 400);
        await sleep(randomBetween(1200, 3500));
        if (Math.random() < 0.3) await moveMouseToElement(container);
      }

      // 3. 多次让最后一条评论 scrollIntoView，带停顿
      const commentNodes = document.querySelectorAll('.comments-container .comment-item, .comments-container [data-testid="comment-item"]');
      for (let i = 0; i < randomBetween(1, 2); i++) {
        if (commentNodes.length > 0) {
          const last = commentNodes[commentNodes.length - 1];
          last.scrollIntoView({behavior: 'smooth', block: 'end'});
          await sleep(randomBetween(800, 2000));
          if (Math.random() < 0.2) await moveMouseToElement(last);
        }
      }

      // 4. 偶尔模拟鼠标点击评论区
      await maybeClickRandom();

      // 5. 判断评论数是否增加或达到上限
      const commentsDetail = getAllCommentsDetail();
      if (commentsDetail.length >= MAX_COMMENTS) {
        console.error('已采集到100条评论，任务终止，自动关闭页面');
        const noteId = getNoteIdFromUrl();
        const noteUrl = window.location.href;
        saveNoteCommentsToLocal(noteId, noteUrl, commentsDetail);
        window.close();
        return;
      }
      if (commentsDetail.length === lastCount) {
        noNewCount++;
        if (noNewCount >= MAX_NO_NEW) {
          console.error('连续两次无新评论，判定采集完毕，自动关闭页面');
          const noteId = getNoteIdFromUrl();
          const noteUrl = window.location.href;
          saveNoteCommentsToLocal(noteId, noteUrl, commentsDetail);
          window.close();
          return;
        }
      } else {
        noNewCount = 0;
      }
      lastCount = commentsDetail.length;
      loop++;
      if (Math.random() < 0.15) {
        await sleep(randomBetween(4000, 9000));
      } else {
        await sleep(randomBetween(2000, 5000));
      }
    }
    // 循环结束也保存
    console.error('达到最大循环次数，自动关闭页面');
    const noteId = getNoteIdFromUrl();
    const noteUrl = window.location.href;
    const commentsDetail = getAllCommentsDetail();
    saveNoteCommentsToLocal(noteId, noteUrl, commentsDetail);
    window.close();
  } catch (e) {
    console.error('采集异常:', e);
    // 异常时也保存已采集到的评论
    const noteId = getNoteIdFromUrl();
    const noteUrl = window.location.href;
    const commentsDetail = getAllCommentsDetail();
    saveNoteCommentsToLocal(noteId, noteUrl, commentsDetail);
    window.close();
  }
}

let allowCollect = false;
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.fromPlugin) {
    // 只有URL为/explore/xxxxxx（有id）才允许采集
    const m = window.location.pathname.match(/\/explore\/(\w+)/);
    if (m && m[1]) {
      allowCollect = true;
      setTimeout(forceLoadAllComments, randomBetween(2000, 5000));
    } else {
      allowCollect = false;
      // 非笔记详情页不采集
    }
  }
});

// 禁止页面自动采集，只有插件消息触发才采集
// window.addEventListener('load', () => {
//   setTimeout(forceLoadAllComments, randomBetween(2000, 5000));
// });

// 风控风险检查说明：
// 1. 本脚本仅在 content script 注入页面，不会主动发起批量请求，不会注入 window.eval/Function 等高危代码。
// 2. 采集逻辑全部基于页面真实渲染内容，无直接接口批量请求行为。
// 3. 如需更低风控风险，建议分批采集、间隔更长时间、避免频繁刷新页面。 