// background.js

function getNextTargetTime() {
  const now = new Date();
  const nextTarget = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 18, 0, 0, 0); // 18:00
  if (now > nextTarget) {
    nextTarget.setDate(nextTarget.getDate() + 1);
  }
  return nextTarget.getTime();
}

function getTodayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `xhs_comments_${y}${m}${day}.json`;
}

chrome.alarms.create('uploadJson', { when: getNextTargetTime(), periodInMinutes: 24 * 60 });

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'uploadJson') {
    const todayKey = getTodayKey();
    chrome.storage.local.get([todayKey], data => {
      if (data[todayKey] && Object.keys(data[todayKey]).length > 0) {
        fetch('http://localhost:3100/upload-and-analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            key: todayKey,
            data: data[todayKey]
          })
        })
        .then(res => res.json())
        .then(resp => console.log('上传并分析结果:', resp))
        .catch(err => console.error('上传或分析失败:', err));
      } else {
        console.log('无数据可上传:', todayKey);
      }
    });
  }
});

// ========== 定时采集主流程迁移到background（chrome.alarms重构） ========== //
// 自动恢复监控功能：后台启动时自动检查monitorRunning
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['monitorRunning'], data => {
    if (data.monitorRunning) {
      console.log('[monitor] 后台启动自动恢复监控任务');
      startMonitorTaskBg();
    }
  });
});

let monitorProgress = { brandId: null, current: 0, total: 0, running: false, retryMap: {} };

function setMonitorProgress(progress) {
  monitorProgress = progress;
  chrome.storage.local.set({ monitorProgress });
}

function startMonitorTaskBg() {
  chrome.storage.local.get({ monitorBrands: [] }, data => {
    const brands = data.monitorBrands || [];
    if (brands.length === 0) {
      setMonitorProgress({ brandId: null, current: 0, total: 0, running: false, retryMap: {} });
      console.log('[monitor] 未找到监控品牌，采集终止');
      return;
    }
    const brand = brands[0];
    monitorProgress = { brandId: brand.id, current: 0, total: brand.noteLinks.length, running: true, retryMap: {} };
    setMonitorProgress(monitorProgress);
    // 计算距离下午3点的毫秒数
    const now = new Date();
    const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6, 0, 0, 0);
    let delay = target - now;
    if (delay < 0) delay = 0; // 已过3点立即开始
    console.log('[monitor] 监控任务启动，延迟(ms):', delay);
    chrome.alarms.create('monitorOpenNote', { when: Date.now() + delay });
  });
}

function runMonitorLinksBg() {
  chrome.storage.local.get({ monitorBrands: [], monitorProgress: {} }, data => {
    const brands = data.monitorBrands || [];
    const progress = data.monitorProgress || {};
    if (!progress.running) {
      console.log('[monitor] 采集任务未运行，终止');
      return;
    }
    if (progress.current >= progress.total) {
      progress.running = false;
      setMonitorProgress(progress);
      console.log('[monitor] 所有笔记采集完毕');
      return;
    }
    const brand = brands.find(b => b.id === progress.brandId) || brands[0];
    const link = brand.noteLinks[progress.current];
    const retryMap = progress.retryMap || {};
    const retryCount = retryMap[progress.current] || 0;
    console.log('[monitor] 打开笔记', progress.current+1, '/', progress.total, link, '重试:', retryCount);
    chrome.tabs.create({ url: link, active: true }, function(tab) {
      // 标记tab为插件自动打开，带重试机制
      sendMessageToTab(tab.id, { fromPlugin: true });
      const tabId = tab.id;
      function onTabRemoved(closedTabId) {
        if (closedTabId === tabId) {
          chrome.tabs.onRemoved.removeListener(onTabRemoved);
          // 检查采集结果
          const todayKey = getTodayKey();
          chrome.storage.local.get([todayKey], d2 => {
            const allData = d2[todayKey] || {};
            let found = false;
            for (const num in allData) {
              if (allData[num] && allData[num].noteUrl === link && allData[num].comments && allData[num].comments.length > 0) {
                found = true;
                break;
              }
            }
            if (found) {
              progress.current++;
              retryMap[progress.current-1] = 0;
            } else {
              // 未采集到，重试
              if (retryCount < 2) {
                retryMap[progress.current] = retryCount + 1;
                console.log('[monitor] 采集失败，重试第', retryCount+1, '次');
              } else {
                progress.current++;
                retryMap[progress.current-1] = 0;
                console.log('[monitor] 采集失败，已达最大重试次数，跳过');
              }
            }
            progress.retryMap = retryMap;
            setMonitorProgress(progress);
            const nextDelay = 60*1000 + Math.floor(Math.random()*120*1000);
            console.log('[monitor] 笔记已关闭，延迟(ms)后打开下一篇:', nextDelay);
            chrome.alarms.create('monitorOpenNote', { when: Date.now() + nextDelay });
          });
        }
      }
      chrome.tabs.onRemoved.addListener(onTabRemoved);
    });
  });
}

function stopMonitorTaskBg() {
  chrome.alarms.clear('monitorOpenNote');
  monitorProgress.running = false;
  setMonitorProgress(monitorProgress);
  console.log('[monitor] 监控任务已停止');
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'START_MONITOR_BG') {
    startMonitorTaskBg();
    sendResponse({ ok: true });
  } else if (msg && msg.type === 'STOP_MONITOR_BG') {
    stopMonitorTaskBg();
    sendResponse({ ok: true });
  }
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'monitorOpenNote') {
    console.log('[monitor] alarm触发，准备打开下一篇笔记');
    runMonitorLinksBg();
  }
});

// 发送消息到tab，带重试机制，防止content script未及时注入
function sendMessageToTab(tabId, msg, retry = 0) {
  chrome.tabs.sendMessage(tabId, msg, res => {
    if (chrome.runtime.lastError) {
      if (retry < 5) {
        setTimeout(() => sendMessageToTab(tabId, msg, retry + 1), 1000);
      } else {
        console.error('content script 连接失败，已重试5次:', chrome.runtime.lastError.message);
      }
    }
  });
} 