function renderComments(allData) {
  const listDiv = document.getElementById('commentList');
  if (!allData || Object.keys(allData).length === 0) {
    listDiv.innerHTML = '<span style="color:#888;">暂无评论</span>';
    return;
  }
  let html = '';
  Object.keys(allData).forEach(num => {
    const note = allData[num];
    html += `<div style="margin-bottom:10px;"><b>笔记${num}：</b><br>链接：<a href="${note.noteUrl}" target="_blank">${note.noteUrl}</a><br>`;
    if (note.comments && note.comments.length > 0) {
      html += note.comments.map((c, i) =>
        `<div style="margin-left:10px;">${i+1}. <b>${c.user||'-'}</b> [${c.time||'-'}]：${c.content}</div>`
      ).join('');
    } else {
      html += '<div style="margin-left:10px;color:#888;">暂无评论</div>';
    }
    html += '</div>';
  });
  listDiv.innerHTML = html;
}

document.addEventListener('DOMContentLoaded', function() {
  const today = new Date();
  const y = today.getFullYear();
  const m = (today.getMonth() + 1).toString().padStart(2, '0');
  const d = today.getDate().toString().padStart(2, '0');
  const key = `xhs_comments_${y}${m}${d}.json`;
  chrome.storage.local.get([key], function(data) {
    renderComments(data[key]);
  });

  // 下载最近7天评论数据
  document.getElementById('download7Btn').onclick = function() {
    let downloaded = 0;
    for (let i = 0; i < 7; i++) {
      const date = new Date(today.getTime() - i * 24 * 60 * 60 * 1000);
      const y = date.getFullYear();
      const m = (date.getMonth() + 1).toString().padStart(2, '0');
      const d = date.getDate().toString().padStart(2, '0');
      const key = `xhs_comments_${y}${m}${d}.json`;
      chrome.storage.local.get([key], function(data) {
        if (data[key] && Object.keys(data[key]).length > 0) {
          const blob = new Blob([JSON.stringify(data[key], null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = key;
          a.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
        }
      });
      downloaded++;
      if (downloaded >= 7) break;
    }
  };

  // 新增：获取昨天日期字符串和key
  function getYesterdayStr() {
    const yesterday = new Date(Date.now() - 24*60*60*1000);
    return `${yesterday.getFullYear()}-${(yesterday.getMonth()+1).toString().padStart(2,'0')}-${yesterday.getDate().toString().padStart(2,'0')}`;
  }
  function getYesterdayKey() {
    const yesterday = new Date(Date.now() - 24*60*60*1000);
    const y = yesterday.getFullYear();
    const m = (yesterday.getMonth() + 1).toString().padStart(2, '0');
    const d = yesterday.getDate().toString().padStart(2, '0');
    return `xhs_comments_${y}${m}${d}.json`;
  }

  // 下载昨日数据按钮
  document.getElementById('downloadTodayBtn').onclick = function() {
    const key = getYesterdayKey();
    chrome.storage.local.get([key], function(data) {
      if (data[key] && Object.keys(data[key]).length > 0) {
        const blob = new Blob([JSON.stringify(data[key], null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      } else {
        alert('昨日暂无数据');
      }
    });
  };

  // 上传并分析按钮（分析昨天数据）
  const statusMsg = document.getElementById('statusMsg');
  const downloadReportBtn = document.getElementById('downloadReportBtn');
  const refreshStatusBtn = document.getElementById('refreshStatusBtn');
  let lastReportUrl = '';
  let isAnalyzing = false;

  function setStatus(msg, color = '#888') {
    statusMsg.style.display = 'block';
    statusMsg.textContent = msg;
    statusMsg.style.color = color;
    chrome.storage.local.set({
      xhs_popup_status: { statusMsg: msg, statusColor: color, reportUrl: lastReportUrl, isAnalyzing }
    });
  }

  function hideStatus() {
    statusMsg.style.display = 'none';
    chrome.storage.local.remove('xhs_popup_status');
  }

  function checkReportAndUpdateUI(reportUrl) {
    if (!reportUrl) {
      isAnalyzing = false;
      hideStatus();
      downloadReportBtn.style.display = 'none';
      refreshStatusBtn.style.display = 'none';
      return;
    }
    let fullUrl = reportUrl;
    if (!/^https?:\/\//.test(reportUrl)) {
      fullUrl = 'http://localhost:3100' + reportUrl;
    }
    console.log('检测报告文件URL:', fullUrl);
    fetch(fullUrl, { method: 'HEAD' }).then(resp => {
      if (resp.ok) {
        if (isAnalyzing) {
          // 分析完成后自动切换为最新
          isAnalyzing = false;
          setStatus('分析完成！可点击下方按钮下载报告', '#22c55e');
        }
        downloadReportBtn.style.display = 'inline-block';
        refreshStatusBtn.style.display = 'none';
        chrome.storage.local.set({
          xhs_popup_status: {
            statusMsg: '分析完成！可点击下方按钮下载报告',
            statusColor: '#22c55e',
            reportUrl: fullUrl,
            isAnalyzing: false
          }
        });
        lastReportUrl = fullUrl;
        console.log('分析完成后lastReportUrl:', lastReportUrl);
      } else {
        hideStatus();
        downloadReportBtn.style.display = 'none';
        refreshStatusBtn.style.display = 'none';
      }
    }).catch(() => {
      hideStatus();
      downloadReportBtn.style.display = 'none';
      refreshStatusBtn.style.display = 'none';
    });
  }

  downloadReportBtn.onclick = function() {
    console.log('下载按钮点击，lastReportUrl:', lastReportUrl);
    if (lastReportUrl) {
      if (isAnalyzing) {
        alert('当前为上次分析结果，分析完成后自动刷新。');
      }
      window.open(lastReportUrl + '?t=' + Date.now(), '_blank');
    } else {
      alert('报告链接无效，请刷新页面或重试');
    }
  };

  refreshStatusBtn.onclick = function() {
    if (lastReportUrl) {
      checkReportAndUpdateUI(lastReportUrl);
    } else {
      hideStatus();
      downloadReportBtn.style.display = 'none';
      refreshStatusBtn.style.display = 'none';
    }
  };

  // 弹窗初始化时恢复状态，并检测报告文件是否已生成
  chrome.storage.local.get('xhs_popup_status', data => {
    if (data.xhs_popup_status) {
      isAnalyzing = !!data.xhs_popup_status.isAnalyzing;
      setStatus(data.xhs_popup_status.statusMsg, data.xhs_popup_status.statusColor);
      if (data.xhs_popup_status.reportUrl) {
        lastReportUrl = data.xhs_popup_status.reportUrl;
        checkReportAndUpdateUI(lastReportUrl);
      } else {
        hideStatus();
        downloadReportBtn.style.display = 'none';
        refreshStatusBtn.style.display = 'none';
      }
    } else {
      isAnalyzing = false;
      hideStatus();
      downloadReportBtn.style.display = 'none';
      refreshStatusBtn.style.display = 'none';
    }
  });

  // 上传并分析按钮（分析昨天数据）
  document.getElementById('uploadAndAnalyzeBtn').onclick = function() {
    isAnalyzing = true;
    setStatus('正在上传并分析，请稍候...\n当前为上次分析结果，分析完成后自动刷新。');
    downloadReportBtn.style.display = 'inline-block';
    refreshStatusBtn.style.display = 'inline-block';
    chrome.storage.local.set({ xhs_popup_status: { statusMsg: '正在上传并分析，请稍候...\n当前为上次分析结果，分析完成后自动刷新。', statusColor: '#888', reportUrl: lastReportUrl, isAnalyzing: true } });
    const key = getYesterdayKey();
    chrome.storage.local.get([key, 'monitorBrands', 'lastAnalyzeDate'], function(data) {
      let analyzeScope = 'yesterday';
      const brands = data.monitorBrands || [];
      let isFirstDayAll = false;
      if (brands.length > 0 && brands[0].noteLinks && brands[0].createdAt) {
        const created = new Date(brands[0].createdAt);
        const yesterdayStr = getYesterdayStr();
        const createdStr = `${created.getFullYear()}-${(created.getMonth()+1).toString().padStart(2,'0')}-${created.getDate().toString().padStart(2,'0')}`;
        // 仅昨天首次分析传all
        if (createdStr === yesterdayStr && data.lastAnalyzeDate !== yesterdayStr) {
          isFirstDayAll = true;
        }
      }
      if (isFirstDayAll) analyzeScope = 'all';
      // 记录本次分析日期
      chrome.storage.local.set({ lastAnalyzeDate: getYesterdayStr() });
      if (data[key] && Object.keys(data[key]).length > 0) {
        // 打印上传数据条数和结构
        console.log('上传分析数据条数:', Array.isArray(data[key]) ? data[key].length : Object.keys(data[key]||{}).length);
        console.log('上传分析数据结构:', data[key]);
        fetch('http://localhost:3100/upload-and-analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key, data: data[key], analyzeScope })
        })
        .then(res => res.json())
        .then(resp => {
          console.log('分析返回:', resp);
          if (resp.status === 'ok' && (resp.reportUrl || resp.reportFileName)) {
            let url = resp.reportUrl;
            if (!url && resp.reportFileName) {
              url = '/xhs_json/' + resp.reportFileName;
            }
            lastReportUrl = 'http://localhost:3100' + url;
            checkReportAndUpdateUI(lastReportUrl);
          } else {
            hideStatus();
            downloadReportBtn.style.display = 'none';
            refreshStatusBtn.style.display = 'none';
            setStatus('分析失败: ' + (resp.error || '未知错误'), '#ef4444');
          }
        })
        .catch(err => {
          hideStatus();
          downloadReportBtn.style.display = 'none';
          refreshStatusBtn.style.display = 'none';
          setStatus('上传或分析失败: ' + err, '#ef4444');
        });
      } else {
        hideStatus();
        downloadReportBtn.style.display = 'none';
        refreshStatusBtn.style.display = 'none';
        setStatus('昨日暂无数据', '#ef4444');
      }
    });
  };

  // 引入xlsx解析库（SheetJS）
  // 需在manifest中web_accessible_resources或CDN引入，或后续补充

  // 1. 监控表单弹窗逻辑
  const addMonitorBtn = document.getElementById('addMonitorBtn');
  const monitorFormModal = document.getElementById('monitorFormModal');
  const monitorFormCancelBtn = document.getElementById('monitorFormCancelBtn');
  const monitorFormConfirmBtn = document.getElementById('monitorFormConfirmBtn');
  const brandDescInput = document.getElementById('brandDescInput');
  const monitorReqInput = document.getElementById('monitorReqInput');
  const noteFileInput = document.getElementById('noteFileInput');
  const editMonitorBtn = document.getElementById('editMonitorBtn');

  addMonitorBtn.onclick = () => {
    monitorFormModal.style.display = 'flex';
  };
  monitorFormCancelBtn.onclick = () => {
    monitorFormModal.style.display = 'none';
  };

  monitorFormConfirmBtn.onclick = async () => {
    const brandDesc = brandDescInput.value.trim();
    const monitorReq = monitorReqInput.value.trim();
    const file = noteFileInput.files[0];
    let analyzeScope = 'today';
    if (file) {
      analyzeScope = 'all';
    }
    // 解析excel
    const reader = new FileReader();
    reader.onload = function(e) {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, {type: 'array'});
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const links = [];
      let row = 2;
      while (true) {
        const cell = sheet['A'+row];
        if (!cell || !cell.v) break;
        links.push(cell.v);
        row++;
      }
      // 保存到chrome.storage.local，结构预留多品牌
      chrome.storage.local.get({monitorBrands: []}, function(data) {
        const brands = data.monitorBrands || [];
        brands.push({
          id: Date.now(),
          brandDesc,
          monitorReq,
          noteLinks: links,
          createdAt: Date.now() // 新增
        });
        chrome.storage.local.set({monitorBrands: brands}, function() {
          // 新增：首次添加监控后立即上传并分析，analyzeScope: 'all'
          const today = new Date();
          const y = today.getFullYear();
          const m = (today.getMonth() + 1).toString().padStart(2, '0');
          const d = today.getDate().toString().padStart(2, '0');
          const key = `xhs_comments_${y}${m}${d}.json`;
          chrome.storage.local.get([key], function(data2) {
            fetch('http://localhost:3100/upload-and-analyze', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ key, data: data2[key] || {}, brandDesc, monitorReq, analyzeScope })
            });
            // 记录本次分析日期
            chrome.storage.local.set({ lastAnalyzeDate: getTodayStr() });
          });
          alert('监控信息已保存');
          monitorFormModal.style.display = 'none';
          brandDescInput.value = '';
          monitorReqInput.value = '';
          noteFileInput.value = '';
        });
      });
    };
    if (file) {
      reader.readAsArrayBuffer(file);
    }
  };

  // 编辑监控信息按钮逻辑
  editMonitorBtn.onclick = () => {
    chrome.storage.local.get({monitorBrands: []}, function(data) {
      const brands = data.monitorBrands || [];
      if (brands.length === 0) {
        alert('暂无监控信息，请先添加');
        return;
      }
      const brand = brands[0];
      brandDescInput.value = brand.brandDesc || '';
      monitorReqInput.value = brand.monitorReq || '';
      noteFileInput.value = '';
      document.getElementById('noteLinksInfo').textContent = `已保存${brand.noteLinks.length}条笔记链接，如需更换请重新上传excel文件`;
      monitorFormModal.style.display = 'flex';
      monitorFormConfirmBtn.onclick = async () => {
        const brandDesc = brandDescInput.value.trim();
        const monitorReq = monitorReqInput.value.trim();
        const file = noteFileInput.files[0];
        let analyzeScope = 'today';
        function saveBrand(links) {
          brands[0] = {
            id: brand.id,
            brandDesc,
            monitorReq,
            noteLinks: links
          };
          chrome.storage.local.set({monitorBrands: brands}, function() {
            // 编辑监控时重新上传excel，analyzeScope: 'all'，否则'today'
            const today = new Date();
            const y = today.getFullYear();
            const m = (today.getMonth() + 1).toString().padStart(2, '0');
            const d = today.getDate().toString().padStart(2, '0');
            const key = `xhs_comments_${y}${m}${d}.json`;
            chrome.storage.local.get([key], function(data2) {
              fetch('http://localhost:3100/upload-and-analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key, data: data2[key] || {}, brandDesc, monitorReq, analyzeScope: file ? 'all' : 'today' })
              });
            });
            alert('监控信息已更新');
            monitorFormModal.style.display = 'none';
            brandDescInput.value = '';
            monitorReqInput.value = '';
            noteFileInput.value = '';
            document.getElementById('noteLinksInfo').textContent = '';
          });
        }
        if (file) {
          const reader = new FileReader();
          reader.onload = function(e) {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, {type: 'array'});
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const links = [];
            let row = 2;
            while (true) {
              const cell = sheet['A'+row];
              if (!cell || !cell.v) break;
              links.push(cell.v);
              row++;
            }
            saveBrand(links);
          };
          reader.readAsArrayBuffer(file);
        } else {
          saveBrand(brand.noteLinks);
        }
      };
    });
  };

  // 添加监控时也显示noteLinksInfo为空
  addMonitorBtn.onclick = () => {
    monitorFormModal.style.display = 'flex';
    document.getElementById('noteLinksInfo').textContent = '';
  };

  // 监控定时采集主流程
  let monitorTimer = null;
  let monitorProgress = { brandId: null, current: 0, total: 0, running: false };

  function setMonitorStatus(msg, color = '#888') {
    statusMsg.style.display = 'block';
    statusMsg.textContent = msg;
    statusMsg.style.color = color;
  }

  function hideMonitorStatus() {
    statusMsg.style.display = 'none';
  }

  function startMonitorTask() {
    chrome.storage.local.get({monitorBrands: []}, data => {
      const brands = data.monitorBrands || [];
      if (brands.length === 0) {
        setMonitorStatus('未找到监控品牌，请先添加', '#ef4444');
        updateStatusBar();
        return;
      }
      const brand = brands[0];
      monitorProgress = { brandId: brand.id, current: 0, total: brand.noteLinks.length, running: true };
      setMonitorStatus('监控任务已启动，等待下午3点自动采集...', '#22c55e');
      chrome.storage.local.set({monitorProgress}, updateStatusBar);
      // 计算距离下午3点的毫秒数
      const now = new Date();
      const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 15, 0, 0, 0);
      let delay = target - now;
      if (delay < 0) delay = 0; // 已过3点立即开始
      monitorTimer = setTimeout(() => {
        runMonitorLinks(brand);
      }, delay);
    });
  }

  // 采集和分析状态合并显示
  // 删除分析状态定时轮询相关代码
  // 只在分析任务真正开始时显示“分析中”，分析完成后显示“分析已完成”
  // 1. 移除pollAnalysisStatus函数和相关定时器
  // 2. 在上传并分析按钮、自动分析任务触发时setMonitorStatus('分析中，请稍候...', '#f59e42');
  // 3. 分析完成后setMonitorStatus('分析已完成，可下载今日报告', '#22c55e');
  // 监控任务完成后自动开始分析状态轮询
  function runMonitorLinks(brand) {
    if (!monitorProgress.running) return;
    if (monitorProgress.current >= brand.noteLinks.length) {
      setMonitorStatus('今日采集已完成', '#22c55e');
      monitorProgress.running = false;
      chrome.storage.local.set({monitorProgress}, updateStatusBar);
      return;
    }
    const link = brand.noteLinks[monitorProgress.current];
    setMonitorStatus(`正在采集第${monitorProgress.current+1||1}/${brand.noteLinks.length}篇笔记...`, '#4285f4');
    chrome.storage.local.set({monitorProgress}, updateStatusBar);
    chrome.tabs.create({ url: link }, function(tab) {
      const tabId = tab.id;
      function onTabRemoved(closedTabId) {
        if (closedTabId === tabId) {
          chrome.tabs.onRemoved.removeListener(onTabRemoved);
          monitorProgress.current++;
          chrome.storage.local.set({monitorProgress}, updateStatusBar);
          const nextDelay = 60*1000 + Math.floor(Math.random()*120*1000);
          monitorTimer = setTimeout(() => runMonitorLinks(brand), nextDelay);
        }
      }
      chrome.tabs.onRemoved.addListener(onTabRemoved);
    });
  }

  function stopMonitorTask() {
    if (monitorTimer) clearTimeout(monitorTimer);
    monitorProgress.running = false;
    chrome.storage.local.set({monitorProgress});
    setMonitorStatus('监控已停止', '#888');
  }

  // 监控按钮逻辑增强
  // 移除本地定时采集主流程和相关定时器
  // 监控按钮通过消息通知background.js
  const toggleMonitorBtn = document.getElementById('toggleMonitorBtn');
  let monitorRunning = false;
  chrome.storage.local.get(['monitorRunning','monitorProgress'], data => {
    monitorRunning = !!data.monitorRunning;
    if (data.monitorProgress) monitorProgress = data.monitorProgress;
    toggleMonitorBtn.textContent = monitorRunning ? '停止监控' : '开启监控';
    if (monitorRunning && monitorProgress.running) {
      setMonitorStatus(`监控任务进行中：第${monitorProgress.current}/${monitorProgress.total}篇`, '#4285f4');
    }
  });
  toggleMonitorBtn.onclick = () => {
    monitorRunning = !monitorRunning;
    chrome.storage.local.set({monitorRunning}, () => {
      toggleMonitorBtn.textContent = monitorRunning ? '停止监控' : '开启监控';
      if (monitorRunning) {
        monitorProgress = { brandId: null, current: 0, total: 0, running: false };
        chrome.storage.local.set({monitorProgress}, () => {
          chrome.runtime.sendMessage({ type: 'START_MONITOR_BG' }, () => {
            updateStatusBar();
          });
        });
      } else {
        chrome.runtime.sendMessage({ type: 'STOP_MONITOR_BG' }, () => {
          chrome.storage.local.set({monitorProgress: { brandId: null, current: 0, total: 0, running: false }}, updateStatusBar);
        });
      }
    });
  };

  // 3. 下载报告按钮逻辑
  const downloadTodayReportBtn = document.getElementById('downloadTodayReportBtn');
  const download7ReportBtn = document.getElementById('download7ReportBtn');

  function getYesterdayReportName() {
    const yesterday = new Date(Date.now() - 24*60*60*1000);
    const y = yesterday.getFullYear();
    const m = (yesterday.getMonth() + 1).toString().padStart(2, '0');
    const d = yesterday.getDate().toString().padStart(2, '0');
    return `xhs_comments_${y}${m}${d}_report.txt`;
  }
  function get7ReportNames() {
    const arr = [];
    const today = new Date();
    for (let i = 0; i < 7; i++) {
      const date = new Date(today.getTime() - i * 24 * 60 * 60 * 1000);
      const y = date.getFullYear();
      const m = (date.getMonth() + 1).toString().padStart(2, '0');
      const d = date.getDate().toString().padStart(2, '0');
      arr.push(`xhs_comments_${y}${m}${d}_report.txt`);
    }
    return arr;
  }

  function downloadReport(filename) {
    const url = `http://localhost:3100/xhs_json/${filename}`;
    window.open(url, '_blank');
  }

  downloadTodayReportBtn.onclick = () => {
    downloadReport(getYesterdayReportName());
  };
  download7ReportBtn.onclick = () => {
    get7ReportNames().forEach(name => downloadReport(name));
  };

  // 插件弹窗初始化时自动轮询分析状态
  // 优化状态栏逻辑：优先显示监控/采集进度，其次显示分析状态
  function updateStatusBar() {
    chrome.storage.local.get(['monitorBrands', 'monitorRunning', 'monitorProgress'], data => {
      const brands = data.monitorBrands || [];
      if (brands.length === 0) {
        setMonitorStatus('暂无监控任务', '#888');
        return;
      }
      const monitorRunning = !!data.monitorRunning;
      const progress = data.monitorProgress || {};
      // 监控进行中且采集未完成
      if (monitorRunning && progress.running && progress.total) {
        setMonitorStatus(`正在采集第${progress.current+1||1}/${progress.total}篇笔记...`, '#4285f4');
        return;
      }
      // 采集已完成但分析未完成
      if (progress.total && progress.current >= progress.total) {
        setMonitorStatus('今日采集已完成', '#22c55e');
        return;
      }
      // 没有监控、没有采集进度、没有报告
      const today = new Date();
      const y = today.getFullYear();
      const m = (today.getMonth() + 1).toString().padStart(2, '0');
      const d = today.getDate().toString().padStart(2, '0');
      const reportUrl = `http://localhost:3100/xhs_json/xhs_comments_${y}${m}${d}_report.txt`;
      fetch(reportUrl, { method: 'HEAD' }).then(resp => {
        if (resp.ok) {
          setMonitorStatus('分析已完成，可下载今日报告', '#22c55e');
        } else {
          setMonitorStatus('监控未开启，等待采集...', '#888');
        }
      }).catch(() => {
        setMonitorStatus('监控未开启，等待采集...', '#888');
      });
    });
  }
  // 修改所有set/poll状态入口，统一调用updateStatusBar
  // 监控按钮、runMonitorLinks、采集完成、弹窗初始化等处调用updateStatusBar
  // 弹窗初始化时
  updateStatusBar();
  // 监控按钮切换时
  toggleMonitorBtn.onclick = () => {
    monitorRunning = !monitorRunning;
    chrome.storage.local.set({monitorRunning}, () => {
      toggleMonitorBtn.textContent = monitorRunning ? '停止监控' : '开启监控';
      if (monitorRunning) {
        monitorProgress = { brandId: null, current: 0, total: 0, running: false };
        chrome.storage.local.set({monitorProgress}, () => {
          chrome.runtime.sendMessage({ type: 'START_MONITOR_BG' }, () => {
            updateStatusBar();
          });
        });
      } else {
        chrome.runtime.sendMessage({ type: 'STOP_MONITOR_BG' }, () => {
          chrome.storage.local.set({monitorProgress: { brandId: null, current: 0, total: 0, running: false }}, updateStatusBar);
        });
      }
    });
  };
  // runMonitorLinks和采集完成后也加updateStatusBar
  function runMonitorLinks(brand) {
    if (!monitorProgress.running) return;
    if (monitorProgress.current >= brand.noteLinks.length) {
      setMonitorStatus('今日采集已完成', '#22c55e');
      monitorProgress.running = false;
      chrome.storage.local.set({monitorProgress}, updateStatusBar);
      return;
    }
    const link = brand.noteLinks[monitorProgress.current];
    setMonitorStatus(`正在采集第${monitorProgress.current+1||1}/${brand.noteLinks.length}篇笔记...`, '#4285f4');
    chrome.storage.local.set({monitorProgress}, updateStatusBar);
    chrome.tabs.create({ url: link }, function(tab) {
      const tabId = tab.id;
      function onTabRemoved(closedTabId) {
        if (closedTabId === tabId) {
          chrome.tabs.onRemoved.removeListener(onTabRemoved);
          monitorProgress.current++;
          chrome.storage.local.set({monitorProgress}, updateStatusBar);
          const nextDelay = 60*1000 + Math.floor(Math.random()*120*1000);
          monitorTimer = setTimeout(() => runMonitorLinks(brand), nextDelay);
        }
      }
      chrome.tabs.onRemoved.addListener(onTabRemoved);
    });
  }

  // 修改按钮文本
  document.getElementById('uploadAndAnalyzeBtn').textContent = '上传并分析昨日评论';
  document.getElementById('downloadTodayBtn').textContent = '下载昨日数据';
  document.getElementById('downloadTodayReportBtn').textContent = '下载昨日报告';
}); 